def arithmetic_arranger(problems):


    return arranged_problems